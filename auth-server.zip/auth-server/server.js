const http = require('http');
const fs = require('fs');
const path = require('path');
const https = require('https');
const crypto = require('crypto');

// ─── Config ───
const PORT = 4032;
const USERS_FILE = path.join(__dirname, 'users.json');
const DATA_DIR = path.join(__dirname, 'data');
const DISCORD_WEBHOOK = 'https://discord.com/api/webhooks/1486052979764236460/vypxQrjdcJqLuNAaqRcDcBox7fiV4OV3mkcRI_inrCTe7fpmveRNz5FCSQcR97vfZ_tu';
const IP_COOLDOWN_MS = 6 * 60 * 60 * 1000; // 6 hours
const ALLOWED_ORIGINS = ['http://localhost:3000', 'http://localhost:3001', 'https://li-auto-ads.vercel.app'];

// ─── In-Memory State ───
const sessions = new Map();       // token -> { pin, role, name, ip, created }
const ipRegisterLog = new Map();  // ip -> timestamp of last register
const ipLoginLog = new Map();     // ip -> timestamp of last login

// ─── Helpers ───
function loadUsers() {
    try { return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8')); }
    catch { return { users: [{ name: 'Admin', pin: '7978', role: 'admin' }] }; }
}
function saveUsers(data) {
    fs.writeFileSync(USERS_FILE, JSON.stringify(data, null, 2), 'utf8');
}
function genToken() { return crypto.randomBytes(32).toString('hex'); }

function getIP(req) {
    return req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress || '0.0.0.0';
}

function readBody(req) {
    return new Promise((resolve, reject) => {
        let body = '';
        req.on('data', c => body += c);
        req.on('end', () => { try { resolve(JSON.parse(body || '{}')); } catch { resolve({}); } });
        req.on('error', reject);
    });
}

function send(res, status, data) {
    const body = JSON.stringify(data);
    res.writeHead(status, { 'Content-Type': 'application/json' });
    res.end(body);
}

function cors(req, res) {
    const origin = req.headers.origin || '';
    // Allow any origin that matches our list, or any for dev
    const allowed = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
    res.setHeader('Access-Control-Allow-Origin', allowed);
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
}

function getSession(req) {
    const auth = req.headers.authorization;
    if (!auth?.startsWith('Bearer ')) return null;
    return sessions.get(auth.slice(7)) || null;
}

function isAdmin(req) {
    const s = getSession(req);
    return s && s.role === 'admin';
}

// ─── Discord Webhook ───
function sendDiscordEmbed(username, howFound, ip) {
    const embed = {
        embeds: [{
            title: '🔔 New Registration Request',
            color: 0x5865F2,
            fields: [
                { name: '👤 Discord Username', value: username, inline: true },
                { name: '🔍 How they found the site', value: howFound || 'Not specified', inline: true },
                { name: '🌐 IP Address', value: `\`${ip}\``, inline: true },
                { name: '⏰ Timestamp', value: new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata', timeZoneName: 'short' }), inline: false }
            ],
            footer: { text: 'LifeInvaider Auth System' },
            timestamp: new Date().toISOString()
        }]
    };

    const payload = JSON.stringify(embed);
    const url = new URL(DISCORD_WEBHOOK);

    const options = {
        hostname: url.hostname,
        path: url.pathname + url.search,
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) }
    };

    const req = https.request(options, (res) => {
        let data = '';
        res.on('data', c => data += c);
        res.on('end', () => {
            if (res.statusCode >= 400) console.error('[Discord] Webhook error:', res.statusCode, data);
            else console.log('[Discord] Embed sent successfully');
        });
    });
    req.on('error', e => console.error('[Discord] Request error:', e.message));
    req.write(payload);
    req.end();
}

// ─── Data Sync (fetch_data logic) ───
function downloadFile(url, dest) {
    return new Promise((resolve, reject) => {
        const file = fs.createWriteStream(dest);
        https.get(url, (res) => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                file.close();
                fs.unlinkSync(dest);
                return downloadFile(res.headers.location, dest).then(resolve).catch(reject);
            }
            res.pipe(file);
            file.on('finish', () => { file.close(); resolve(); });
            file.on('error', reject);
        }).on('error', reject);
    });
}

function downloadText(url) {
    return new Promise((resolve, reject) => {
        https.get(url, (res) => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                return downloadText(res.headers.location).then(resolve).catch(reject);
            }
            let data = '';
            res.on('data', c => data += c);
            res.on('end', () => resolve(data));
        }).on('error', reject);
    });
}

function expandBracketedItems(items) {
    const expanded = [];
    for (const item of items) {
        const match = item.match(/^(.+?)\s*\(([^)]+)\)\s*$/);
        if (match) {
            const base = match[1].trim();
            const variants = match[2].replace(' and ', ', ').replace('&', ', ');
            expanded.push(base);
            if (variants.includes('quality')) {
                const parts = variants.replace('quality', '').split(',').map(s => s.trim()).filter(Boolean);
                for (const part of parts) expanded.push(`${part} quality ${base}`);
            } else if (variants.includes('%')) {
                const parts = variants.split(',').map(s => s.trim()).filter(Boolean);
                for (const part of parts) expanded.push(`${part} ${base}`);
            } else if (variants.includes('/')) {
                const parts = variants.split('/').map(s => s.trim()).filter(Boolean);
                for (const part of parts) expanded.push(`${part} ${base}`);
            } else if (variants.includes('of type')) {
                if (variants.includes('-')) { expanded.push(item); }
                else {
                    const numsStr = variants.replace('of type', '').replace(/or/g, ',').replace(/and/g, ',').trim();
                    const nums = numsStr.split(',').map(s => s.trim()).filter(Boolean);
                    for (const n of nums) expanded.push(`${base} of type ${n}`);
                }
            } else if (variants.match(/V\.\d+-/)) { expanded.push(item); }
            else { expanded.push(item); }
        } else { expanded.push(item); }
    }
    return [...new Set(expanded)].sort();
}

async function runSync() {
    const xlsx = require('xlsx');
    
    // Read config
    let conf = {};
    const confPath = path.join(DATA_DIR, 'config.json');
    try { conf = JSON.parse(fs.readFileSync(confPath, 'utf8')); } catch {}

    const doc1_url = conf.doc1_url || "https://docs.google.com/document/d/1P-q01QXzwQvz5zkNqngKiJrQUVXkJx1B6Rg8rOXsJxA/export?format=txt";
    const templates_url = conf.templates_url || "https://docs.google.com/spreadsheets/d/1jtNsrDClzDFAEWkTi2xgzuCHKOWy5Rw0tt0XS1gy6PY/export?format=xlsx";
    const cars_url = conf.cars_url || "https://docs.google.com/spreadsheets/d/16EmEoyqlrmxRuPMSwWkxw80oEifwjjpe5AOqYhb70Yc/export?format=xlsx";

    const tempDir = path.join(DATA_DIR, '_temp');
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

    await Promise.all([
        downloadText(doc1_url).then(text => {
            fs.writeFileSync(path.join(DATA_DIR, 'policy.json'), JSON.stringify({ "LifeInvader_Internal_Policy": text }, null, 2));
        }),
        downloadFile(templates_url, path.join(tempDir, '_templates.xlsx')),
        downloadFile(cars_url, path.join(tempDir, '_cars.xlsx'))
    ]);

    const templatesData = {};
    const wbTemplates = xlsx.readFile(path.join(tempDir, '_templates.xlsx'));
    for (const sheetName of wbTemplates.SheetNames) {
        templatesData[sheetName] = xlsx.utils.sheet_to_json(wbTemplates.Sheets[sheetName], { header: 1 });
    }
    fs.writeFileSync(path.join(DATA_DIR, 'templates.json'), JSON.stringify(templatesData, null, 2));

    const itemsData = {};
    const wbCars = xlsx.readFile(path.join(tempDir, '_cars.xlsx'));
    for (const sheetName of wbCars.SheetNames) {
        itemsData[sheetName] = xlsx.utils.sheet_to_json(wbCars.Sheets[sheetName], { header: 1 });
    }
    fs.writeFileSync(path.join(DATA_DIR, 'items.json'), JSON.stringify(itemsData, null, 2));

    const extractFlat = (keys, skipFirst = true, checkEveryColumn = false) => {
        let opts = [];
        keys.forEach(key => {
            const matrix = itemsData[key];
            if (Array.isArray(matrix)) {
                matrix.forEach((row, idx) => {
                    if (skipFirst && idx === 0) return;
                    if (Array.isArray(row)) {
                        const increment = checkEveryColumn ? 1 : 2;
                        for (let i = 0; i < row.length; i += increment) {
                            const cell = row[i];
                            if (cell && cell !== "----" && typeof cell === 'string') opts.push(cell.trim());
                        }
                    }
                });
            }
        });
        return [...new Set(opts)];
    };

    const extractClothing = () => {
        let opts = [];
        const matrix = itemsData['CLOTHING LIST'];
        if (Array.isArray(matrix)) {
            matrix.forEach((row, idx) => {
                if (idx === 0) return;
                if (Array.isArray(row)) {
                    for (let i = 0; i <= 7; i++) {
                        const cell = row[i];
                        if (cell && cell !== "----" && typeof cell === 'string') opts.push(cell.trim());
                    }
                }
            });
        }
        return [...new Set(opts)];
    };

    const cars = extractFlat(['CARS', 'BOATSPLANESHELICOPTERS', 'MOTORCYCLES'], true, false);
    const rawItems = extractFlat(['ITEMS'], true, true);
    const items = expandBracketedItems(rawItems);
    const clothing = extractClothing();

    const parsed = {
        cars: cars.sort(),
        items: items.sort(),
        clothing: clothing.sort(),
        lastUpdated: new Date().toISOString()
    };
    fs.writeFileSync(path.join(DATA_DIR, 'parsed_items.json'), JSON.stringify(parsed, null, 2));

    // Cleanup temp
    try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch {}

    return parsed;
}

// ─── Route Handler ───
async function handleRequest(req, res) {
    cors(req, res);

    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        return res.end();
    }

    const url = req.url.split('?')[0];
    const ip = getIP(req);

    // ── GET /health ──
    if (url === '/health' && req.method === 'GET') {
        return send(res, 200, { ok: true, time: Date.now() });
    }

    // ── POST /login ──
    if (url === '/login' && req.method === 'POST') {
        const body = await readBody(req);
        const pin = String(body.pin || '').trim();
        if (!pin || pin.length !== 4) return send(res, 400, { error: 'PIN must be 4 digits' });

        const data = loadUsers();
        const user = data.users.find(u => u.pin === pin);
        if (!user) return send(res, 401, { error: 'Invalid PIN' });

        const token = genToken();
        sessions.set(token, { pin: user.pin, role: user.role || 'user', name: user.name, ip, created: Date.now() });

        // Lock this IP from registering for 6hrs
        ipLoginLog.set(ip, Date.now());

        return send(res, 200, { token, name: user.name, role: user.role || 'user' });
    }

    // ── POST /register ──
    if (url === '/register' && req.method === 'POST') {
        const body = await readBody(req);
        const { discord_username, how_found } = body;
        if (!discord_username?.trim()) return send(res, 400, { error: 'Discord username is required' });

        // Check if this IP logged in recently (6hr block)
        const lastLogin = ipLoginLog.get(ip);
        if (lastLogin && Date.now() - lastLogin < IP_COOLDOWN_MS) {
            return send(res, 429, { error: 'This device recently logged in. Registration is locked for 6 hours.' });
        }

        // Check IP registration cooldown
        const lastReg = ipRegisterLog.get(ip);
        if (lastReg && Date.now() - lastReg < IP_COOLDOWN_MS) {
            const remainMin = Math.ceil((IP_COOLDOWN_MS - (Date.now() - lastReg)) / 60000);
            return send(res, 429, { error: `Registration cooldown active. Try again in ${remainMin} minutes.` });
        }

        // Log IP and send webhook
        ipRegisterLog.set(ip, Date.now());
        sendDiscordEmbed(discord_username.trim(), how_found?.trim() || 'Not specified', ip);

        return send(res, 200, { success: true, message: 'Registration request sent! An admin will review your request shortly.' });
    }

    // ── GET /validate ──
    if (url === '/validate' && req.method === 'GET') {
        const session = getSession(req);
        if (!session) return send(res, 401, { error: 'Invalid session' });
        return send(res, 200, { valid: true, name: session.name, role: session.role });
    }

    // ── GET /users (admin) ──
    if (url === '/users' && req.method === 'GET') {
        if (!isAdmin(req)) return send(res, 403, { error: 'Admin access required' });
        const data = loadUsers();
        return send(res, 200, { users: data.users.map(u => ({ name: u.name, pin: u.pin, role: u.role || 'user' })) });
    }

    // ── POST /users/add (admin) ──
    if (url === '/users/add' && req.method === 'POST') {
        if (!isAdmin(req)) return send(res, 403, { error: 'Admin access required' });
        const body = await readBody(req);
        const { name, pin } = body;
        if (!name?.trim() || !pin?.trim()) return send(res, 400, { error: 'Name and PIN required' });
        if (pin.length !== 4 || !/^\d{4}$/.test(pin)) return send(res, 400, { error: 'PIN must be exactly 4 digits' });

        const data = loadUsers();
        if (data.users.find(u => u.pin === pin)) return send(res, 409, { error: 'PIN already in use' });
        data.users.push({ name: name.trim(), pin: pin.trim(), role: 'user' });
        saveUsers(data);
        return send(res, 200, { success: true, message: `User "${name}" added.` });
    }

    // ── POST /users/delete (admin) ──
    if (url === '/users/delete' && req.method === 'POST') {
        if (!isAdmin(req)) return send(res, 403, { error: 'Admin access required' });
        const body = await readBody(req);
        const { pin } = body;
        if (pin === '7978') return send(res, 400, { error: 'Cannot delete admin' });
        const data = loadUsers();
        const idx = data.users.findIndex(u => u.pin === pin);
        if (idx === -1) return send(res, 404, { error: 'User not found' });
        data.users.splice(idx, 1);
        saveUsers(data);
        // Also kill any sessions with that pin
        for (const [token, sess] of sessions) {
            if (sess.pin === pin) sessions.delete(token);
        }
        return send(res, 200, { success: true });
    }

    // ── POST /sync (admin) ──
    if (url === '/sync' && req.method === 'POST') {
        if (!isAdmin(req)) return send(res, 403, { error: 'Admin access required' });
        try {
            const parsed = await runSync();
            return send(res, 200, { success: true, lastUpdated: parsed.lastUpdated });
        } catch (e) {
            console.error('[Sync] Error:', e);
            return send(res, 500, { error: 'Sync failed: ' + e.message });
        }
    }

    // ── GET /sync/status ──
    if (url === '/sync/status' && req.method === 'GET') {
        try {
            const p = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'parsed_items.json'), 'utf8'));
            return send(res, 200, { lastUpdated: p.lastUpdated || null });
        } catch {
            return send(res, 200, { lastUpdated: null });
        }
    }

    // ── GET /data/:file ──
    if (url.startsWith('/data/') && req.method === 'GET') {
        const session = getSession(req);
        if (!session) return send(res, 401, { error: 'Login required' });
        const filename = url.slice(6); // strip /data/
        const safeName = path.basename(filename);
        const filePath = path.join(DATA_DIR, safeName);
        if (!fs.existsSync(filePath)) return send(res, 404, { error: 'File not found' });
        try {
            const content = fs.readFileSync(filePath, 'utf8');
            res.writeHead(200, { 'Content-Type': 'application/json' });
            return res.end(content);
        } catch {
            return send(res, 500, { error: 'Read error' });
        }
    }

    // ── POST /config (admin) ──
    if (url === '/config' && req.method === 'POST') {
        if (!isAdmin(req)) return send(res, 403, { error: 'Admin access required' });
        const body = await readBody(req);
        fs.writeFileSync(path.join(DATA_DIR, 'config.json'), JSON.stringify(body, null, 2), 'utf8');
        return send(res, 200, { success: true });
    }

    // ── GET /config (admin) ──
    if (url === '/config' && req.method === 'GET') {
        if (!isAdmin(req)) return send(res, 403, { error: 'Admin access required' });
        try {
            const c = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'config.json'), 'utf8'));
            return send(res, 200, { config: c });
        } catch {
            return send(res, 200, { config: { doc1_url: '', templates_url: '', cars_url: '', last_updated: 'Never' } });
        }
    }

    // ── 404 ──
    send(res, 404, { error: 'Not found' });
}

// ─── Boot ───
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(USERS_FILE)) saveUsers({ users: [{ name: 'Admin', pin: '7978', role: 'admin' }] });

// Cleanup expired IPs every 30 min
setInterval(() => {
    const now = Date.now();
    for (const [ip, ts] of ipRegisterLog) { if (now - ts > IP_COOLDOWN_MS) ipRegisterLog.delete(ip); }
    for (const [ip, ts] of ipLoginLog) { if (now - ts > IP_COOLDOWN_MS) ipLoginLog.delete(ip); }
}, 30 * 60 * 1000);

const server = http.createServer(handleRequest);
server.listen(PORT, '0.0.0.0', () => {
    console.log(`\n  🚀 LifeInvaider Auth Server running on port ${PORT}`);
    console.log(`  📁 Data directory: ${DATA_DIR}`);
    console.log(`  👤 Users file: ${USERS_FILE}\n`);
});
